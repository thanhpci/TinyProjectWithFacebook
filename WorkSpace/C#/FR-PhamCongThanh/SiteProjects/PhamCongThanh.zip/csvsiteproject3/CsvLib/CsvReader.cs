﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using SiteProjectWeek3.CsvLib;
using static System.Net.WebRequestMethods;
using static SiteProjectWeek3.CsvLib.Delegates;

namespace SiteProjectWeek3.CsvLib
{
    internal class CsvReader
    {
        public CsvConfiguration Configuration = new CsvConfiguration();
        public SkippedLineEventHandler SkippedLine { get; set; }



        public ICsvLine[] ReadFromFile(string pathFile)
        {
            List<ICsvLine> lines = new List<ICsvLine>();
            if (System.IO.File.Exists(pathFile))
            {
                using (StreamReader reader = new StreamReader(pathFile))
                {
                    while (!reader.EndOfStream)
                    {
                        string line = reader.ReadLine();

                        var csvLine = new CsvLine();

                        csvLine.Values = line.Split(',');

                       
                        lines.Add(csvLine);
                    }
                }
                return lines.ToArray();
            }
            return new ICsvLine[0];
        }
        

        public ICsvLine[] ReadFromStream(Stream stream)
        {
            if (stream == null || !stream.CanRead)
            {
                return new ICsvLine[0];
            }
            List<ICsvLine> lines = new List<ICsvLine>();
            using (StreamReader reader = new StreamReader(stream))
            {
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();

                    var csvLine = new CsvLine();

                    csvLine.Raw = line;
                    csvLine.Values = line.Split(',');
                    lines.Add(csvLine);
                }
            }
            return lines.ToArray();
        }


        public ICsvLine[] ReadFromString(string csvContent)
        {
            if (string.IsNullOrEmpty(csvContent))
            {
                return new ICsvLine[0];
            }
            List<ICsvLine> lines = new List<ICsvLine>();
            string[] rows = csvContent.Split(new string[] { Environment.NewLine }, StringSplitOptions.None);
            foreach (string row in rows)
            {
                var csvLine = new CsvLine();
                csvLine.Raw = row;
                csvLine.Values = row.Split(',');
                lines.Add(csvLine);
            }
            return lines.ToArray();

            
        }
    }
}
